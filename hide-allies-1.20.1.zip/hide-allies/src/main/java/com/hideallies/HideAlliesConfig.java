package com.hideallies;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class HideAlliesConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("hideallies.json");

    private static boolean enabled = true;
    private static final Set<String> allies = new LinkedHashSet<>(); // sempre minúsculo

    private static final class Data {
        boolean enabled = true;
        List<String> allies = new ArrayList<>();
    }

    private HideAlliesConfig() {}

    public static boolean isEnabled() { return enabled; }

    public static void setEnabled(boolean value) {
        enabled = value;
        save();
    }

    public static boolean isAlly(String name) {
        return name != null && allies.contains(name.toLowerCase(Locale.ROOT));
    }

    public static boolean addAlly(String name) {
        boolean added = allies.add(name.toLowerCase(Locale.ROOT));
        if (added) save();
        return added;
    }

    public static boolean removeAlly(String name) {
        boolean removed = allies.remove(name.toLowerCase(Locale.ROOT));
        if (removed) save();
        return removed;
    }

    public static void clearAllies() {
        allies.clear();
        save();
    }

    public static List<String> getAllies() {
        return new ArrayList<>(allies);
    }

    public static void load() {
        if (!Files.exists(PATH)) { save(); return; }
        try {
            Data d = GSON.fromJson(Files.readString(PATH), Data.class);
            if (d == null) return;
            enabled = d.enabled;
            allies.clear();
            if (d.allies != null) {
                for (String s : d.allies) allies.add(s.toLowerCase(Locale.ROOT));
            }
        } catch (Exception e) {
            HideAlliesClient.LOGGER.error("Falha ao ler config", e);
        }
    }

    public static void save() {
        try {
            Data d = new Data();
            d.enabled = enabled;
            d.allies = new ArrayList<>(allies);
            Files.writeString(PATH, GSON.toJson(d));
        } catch (IOException e) {
            HideAlliesClient.LOGGER.error("Falha ao salvar config", e);
        }
    }
}
