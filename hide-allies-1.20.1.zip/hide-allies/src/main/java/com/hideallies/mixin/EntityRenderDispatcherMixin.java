package com.hideallies.mixin;

import com.hideallies.HideAlliesConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private <E extends Entity> void hideallies$hideAllies(E entity, Frustum frustum, double x, double y, double z,
                                                          CallbackInfoReturnable<Boolean> cir) {
        if (!HideAlliesConfig.isEnabled()) return;
        if (!(entity instanceof PlayerEntity player)) return;
        if (player == MinecraftClient.getInstance().player) return; // nunca esconde você mesmo

        if (HideAlliesConfig.isAlly(player.getGameProfile().getName())) {
            cir.setReturnValue(false); // não renderiza corpo, nametag nem sombra
        }
    }
}
