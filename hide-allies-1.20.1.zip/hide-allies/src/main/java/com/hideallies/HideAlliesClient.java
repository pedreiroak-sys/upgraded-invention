package com.hideallies;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HideAlliesClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("hideallies");

    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        HideAlliesConfig.load();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hideallies.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                "category.hideallies"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                toggle(client);
            }
        });

        registerCommands();
    }

    private static void toggle(MinecraftClient client) {
        boolean now = !HideAlliesConfig.isEnabled();
        HideAlliesConfig.setEnabled(now);
        if (client.player != null) {
            client.player.sendMessage(statusText(now), true); // action bar
        }
    }

    private static Text statusText(boolean on) {
        return Text.literal("Ocultar aliados: ").formatted(Formatting.GRAY)
                .append(Text.literal(on ? "ATIVADO" : "DESATIVADO")
                        .formatted(on ? Formatting.GREEN : Formatting.RED, Formatting.BOLD));
    }

    private void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("aliado")
                    .then(ClientCommandManager.literal("add")
                            .then(ClientCommandManager.argument("nome", StringArgumentType.word())
                                    .suggests((ctx, builder) -> {
                                        var handler = MinecraftClient.getInstance().getNetworkHandler();
                                        if (handler != null) {
                                            for (PlayerListEntry e : handler.getPlayerList()) {
                                                String n = e.getProfile().getName();
                                                if (n.toLowerCase().startsWith(builder.getRemainingLowerCase())
                                                        && !HideAlliesConfig.isAlly(n)) {
                                                    builder.suggest(n);
                                                }
                                            }
                                        }
                                        return builder.buildFuture();
                                    })
                                    .executes(ctx -> {
                                        String nome = StringArgumentType.getString(ctx, "nome");
                                        boolean ok = HideAlliesConfig.addAlly(nome);
                                        ctx.getSource().sendFeedback(Text.literal(ok
                                                ? "✔ " + nome + " adicionado aos aliados."
                                                : nome + " já está na lista.")
                                                .formatted(ok ? Formatting.GREEN : Formatting.YELLOW));
                                        return 1;
                                    })))
                    .then(ClientCommandManager.literal("remove")
                            .then(ClientCommandManager.argument("nome", StringArgumentType.word())
                                    .suggests((ctx, builder) -> {
                                        for (String n : HideAlliesConfig.getAllies()) {
                                            if (n.startsWith(builder.getRemainingLowerCase())) builder.suggest(n);
                                        }
                                        return builder.buildFuture();
                                    })
                                    .executes(ctx -> {
                                        String nome = StringArgumentType.getString(ctx, "nome");
                                        boolean ok = HideAlliesConfig.removeAlly(nome);
                                        ctx.getSource().sendFeedback(Text.literal(ok
                                                ? "✔ " + nome + " removido dos aliados."
                                                : nome + " não está na lista.")
                                                .formatted(ok ? Formatting.GREEN : Formatting.YELLOW));
                                        return 1;
                                    })))
                    .then(ClientCommandManager.literal("list")
                            .executes(ctx -> {
                                var list = HideAlliesConfig.getAllies();
                                ctx.getSource().sendFeedback(Text.literal(list.isEmpty()
                                        ? "Nenhum aliado na lista."
                                        : "Aliados (" + list.size() + "): " + String.join(", ", list))
                                        .formatted(Formatting.AQUA));
                                return 1;
                            }))
                    .then(ClientCommandManager.literal("clear")
                            .executes(ctx -> {
                                HideAlliesConfig.clearAllies();
                                ctx.getSource().sendFeedback(Text.literal("Lista de aliados limpa.")
                                        .formatted(Formatting.YELLOW));
                                return 1;
                            }))
                    .then(ClientCommandManager.literal("toggle")
                            .executes(ctx -> {
                                boolean now = !HideAlliesConfig.isEnabled();
                                HideAlliesConfig.setEnabled(now);
                                ctx.getSource().sendFeedback(statusText(now));
                                return 1;
                            }))
            );
        });
    }
}
